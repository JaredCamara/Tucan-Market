<?php include '../db.php'; include '../cloudinary.php';

if ($_POST) {
    $imagen = subirACloudinary($_FILES['imagen']['tmp_name']);
    $stmt = $conn->prepare("INSERT INTO papeleria (nombre, descripcion, precio, imagen_url) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssds", $_POST['nombre'], $_POST['descripcion'], $_POST['precio'], $imagen);
    $stmt->execute();
    header("Location: listar.php");
}
?>

<form method="POST" enctype="multipart/form-data">
    Nombre: <input name="nombre"><br>
    Descripción: <textarea name="descripcion"></textarea><br>
    Precio: <input name="precio" step="0.01"><br>
    Imagen: <input type="file" name="imagen"><br>
    <button>Guardar</button>
</form>