<!DOCTYPE html>
<html>
<head><title>Panel de administración</title></head>
<body>
<h1>Panel de Administración</h1>
<ul>
    <li><a href="ropa/listar.php">Ropa</a></li>
    <li><a href="tecnologia/listar.php">Tecnología</a></li>
    <li><a href="calzado/listar.php">Calzado</a></li>
    <li><a href="papeleria/listar.php">Papelería</a></li>
</ul>
</body>
</html>