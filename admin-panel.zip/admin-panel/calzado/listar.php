<?php include '../db.php'; ?>
<h2>Lista de calzado</h2>
<a href="crear.php">Agregar nueva</a><br><br>
<?php
$res = $conn->query("SELECT * FROM calzado");
while($row = $res->fetch_assoc()) {
    echo "<div>
        <strong>{$row['nombre']}</strong> - {$row['precio']}<br>
        <img src='{$row['imagen_url']}' width='100'><br>
        <a href='editar.php?id={$row['id']}'>Editar</a> |
        <a href='eliminar.php?id={$row['id']}'>Eliminar</a>
    </div><hr>";
}
?>