<?php include '../db.php'; include '../cloudinary.php';

$id = $_GET['id'];
$res = $conn->query("SELECT * FROM ropa WHERE id=$id");
$ropa = $res->fetch_assoc();

if ($_POST) {
    $imagen = $ropa['imagen_url'];
    if (!empty($_FILES['imagen']['tmp_name'])) {
        $imagen = subirACloudinary($_FILES['imagen']['tmp_name']);
    }
    $stmt = $conn->prepare("UPDATE ropa SET nombre=?, descripcion=?, precio=?, imagen_url=? WHERE id=?");
    $stmt->bind_param("ssdsi", $_POST['nombre'], $_POST['descripcion'], $_POST['precio'], $imagen, $id);
    $stmt->execute();
    header("Location: listar.php");
}
?>

<form method="POST" enctype="multipart/form-data">
    Nombre: <input name="nombre" value="<?= $ropa['nombre'] ?>"><br>
    Descripción: <textarea name="descripcion"><?= $ropa['descripcion'] ?></textarea><br>
    Precio: <input name="precio" step="0.01" value="<?= $ropa['precio'] ?>"><br>
    Imagen: <input type="file" name="imagen"><br>
    <button>Actualizar</button>
</form>